import { useEffect, useState } from "react";
import BasicLayout from "../layout/BasicLayout";

function AboutPage (){

    

    return(
        <BasicLayout>
            <div className="mainPage">
                <h2>About Page</h2>
                
            </div>
        </BasicLayout>
    )

}

export default AboutPage;


            // 배열 함수 : push()-마지막 추가, unshift() - 첫번째 값 추가 / splice() : 특정위치에 추가
            // splice( 삽입할 인덱스위치, 삭제할갯수, 삽입할 값들)
