
const FetchingModal = () => {
    return (
        <div className="fetching modal">
            <div>
                <p>Loading....</p>
            </div>
        </div>
    )
}

export default FetchingModal;